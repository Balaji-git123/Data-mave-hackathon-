# Data Validation App (CSV Version)

A Streamlit-based application to validate data between a **source CSV** and a **target CSV**, handling differences in column naming conventions.

## 🚀 Features
- Upload source and target CSV files
- Validate data using configurable column mappings
- Show mismatches (values missing in source or target)
- Interactive Streamlit UI for hackathon demo

## ⚙️ Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
2. Run the application
streamlit run app.py

3. Upload your CSVs and view validation results.


