import streamlit as st
import pandas as pd
from data.validator import validate_data

st.title("CSV Data Validation App")

src_file = st.file_uploader("Upload Source Table CSV", type="csv")
tgt_file = st.file_uploader("Upload Target Table CSV", type="csv")

if src_file and tgt_file:
    source_df = pd.read_csv(src_file)
    target_df = pd.read_csv(tgt_file)

    st.write("### Source Data Preview")
    st.dataframe(source_df.head())

    st.write("### Target Data Preview")
    st.dataframe(target_df.head())

    st.write("### Validation Results")
    results = validate_data(source_df, target_df)

    for res in results:
        st.subheader(f"{res['source_column']} ↔ {res['target_column']}")
        st.write("Missing in Target:", res["missing_in_target"])
        st.write("Missing in Source:", res["missing_in_source"])
