import pandas as pd
from utils.mappings import COLUMN_MAPPING

def validate_data(source_df: pd.DataFrame, target_df: pd.DataFrame):
    """Validate source vs target data with column mapping."""
    results = []

    for src_col, tgt_col in COLUMN_MAPPING.items():
        if src_col in source_df.columns and tgt_col in target_df.columns:
            src_values = set(source_df[src_col].dropna().unique())
            tgt_values = set(target_df[tgt_col].dropna().unique())

            diff_src = src_values - tgt_values
            diff_tgt = tgt_values - src_values

            results.append({
                "source_column": src_col,
                "target_column": tgt_col,
                "missing_in_target": list(diff_src),
                "missing_in_source": list(diff_tgt)
            })
    return results
