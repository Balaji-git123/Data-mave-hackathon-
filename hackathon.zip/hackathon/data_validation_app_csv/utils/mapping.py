COLUMN_MAPPING = {
    "name": "name_c",
    "age": "age_c",
    "salary": "salary_amt"
}
