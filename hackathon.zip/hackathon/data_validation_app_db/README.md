# Data Validation App (DB Version)

A Streamlit-based application to validate data between a **source database table** and a **target database table**, handling differences in column naming conventions.

## 🚀 Features
- Connect to two SQLite databases
- Fetch tables with `SELECT *`
- Validate data using configurable column mappings
- Show mismatches (values missing in source or target)
- Interactive Streamlit UI for hackathon demo

## ⚙️ Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
2. Run the application
streamlit run app.py
3. Enter DB paths and table names in the UI, then run validation.

---
