import streamlit as st
from source.db_connection import get_connection, fetch_table_as_df
from data.validator import validate_data

st.title("DB Data Validation App")

db1_path = st.text_input("Source DB Path", "source.db")
db2_path = st.text_input("Target DB Path", "target.db")
table1 = st.text_input("Source Table Name", "table1")
table2 = st.text_input("Target Table Name", "table2")

if st.button("Run Validation"):
    conn1 = get_connection(db1_path)
    conn2 = get_connection(db2_path)

    source_df = fetch_table_as_df(conn1, table1)
    target_df = fetch_table_as_df(conn2, table2)

    st.write("### Source Data Preview")
    st.dataframe(source_df.head())

    st.write("### Target Data Preview")
    st.dataframe(target_df.head())

    st.write("### Validation Results")
    results = validate_data(source_df, target_df)

    for res in results:
        st.subheader(f"{res['source_column']} ↔ {res['target_column']}")
        st.write("Missing in Target:", res["missing_in_target"])
        st.write("Missing in Source:", res["missing_in_source"])