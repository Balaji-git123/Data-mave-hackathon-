import sqlite3
import pandas as pd

def get_connection(db_path: str):
    """Create a connection to the database."""
    return sqlite3.connect(db_path)

def fetch_table_as_df(conn, table_name: str):
    """Run SELECT * and return as DataFrame."""
    query = f"SELECT * FROM {table_name}"
    return pd.read_sql(query, conn)
